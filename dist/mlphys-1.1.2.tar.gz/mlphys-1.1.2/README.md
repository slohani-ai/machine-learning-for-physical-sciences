# Machine Learning for Physical Sciences
### pip install mlphys